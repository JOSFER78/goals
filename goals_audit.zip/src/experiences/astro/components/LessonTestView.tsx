/**
 * GOALS 3D Cosmos - LessonTestView
 * Bloque 3: Test & Reto de Conocimiento Interactivo con Recompensas de XP,
 * Estrellas (0-3 ⭐), soporte para fotos de examen, minijuego de ordenación y Explicaciones Formativas.
 */

import React, { useState } from 'react';
import { Lesson, Question, ChoiceQuestion, OrderQuestion } from '../types';
import { useProgress } from '../../../core/context/ProgressContext';
import { Award, CheckCircle2, XCircle, Star, ArrowRight, RotateCcw, Rocket, Lightbulb, BookOpen } from 'lucide-react';
import { InteractiveOrderList } from './interactive/InteractiveOrderList';

interface LessonTestViewProps {
  lesson: Lesson;
  onFinishTest: (score: number, total: number) => void;
  onGoToNextLesson: () => void;
  onGoTo3D: () => void;
  onGoToCatalog?: () => void;
}

export const LessonTestView: React.FC<LessonTestViewProps> = ({
  lesson,
  onFinishTest,
  onGoToNextLesson,
  onGoTo3D,
  onGoToCatalog
}) => {
  const { finishTest, addXP } = useProgress();
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, any>>({});
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);

  const questions = lesson.test || [];
  const currentQ: Question = questions[currentQuestionIdx] || questions[0];

  const handleSelectChoice = (optionIdx: number) => {
    if (userAnswers[currentQuestionIdx] !== undefined) return;
    setUserAnswers(prev => ({ ...prev, [currentQuestionIdx]: optionIdx }));
  };

  const handleOrderChange = (_newOrder: string[]) => {
    // Estado transitorio mientras el usuario arrastra
  };

  const handleConfirmOrder = (finalOrder: string[]) => {
    setUserAnswers(prev => ({ ...prev, [currentQuestionIdx]: finalOrder }));
  };

  const handleNextQuestion = () => {
    if (currentQuestionIdx < questions.length - 1) {
      setCurrentQuestionIdx(prev => prev + 1);
    } else {
      // Cálculo del score final
      let totalCorrect = 0;
      questions.forEach((q, idx) => {
        const ans = userAnswers[idx];
        if (q.type === 'choice' && ans === (q as ChoiceQuestion).answer) {
          totalCorrect++;
        } else if (q.type === 'order' && JSON.stringify(ans) === JSON.stringify((q as OrderQuestion).correctOrder)) {
          totalCorrect++;
        }
      });

      setScore(totalCorrect);
      setIsSubmitted(true);

      const xpEarned = totalCorrect * 25 + 25;
      finishTest(lesson.id, totalCorrect, questions.length);
      addXP(xpEarned, 'astro', `Test Completado: ${lesson.title}`);
      onFinishTest(totalCorrect, questions.length);
    }
  };

  const handleRetry = () => {
    setUserAnswers({});
    setCurrentQuestionIdx(0);
    setIsSubmitted(false);
    setScore(0);
  };

  const isCurrentAnswered = userAnswers[currentQuestionIdx] !== undefined;
  const isChoice = currentQ && currentQ.type === 'choice';
  const choiceQ = currentQ as ChoiceQuestion;
  const orderQ = currentQ as OrderQuestion;

  const isCurrentCorrect = isChoice
    ? userAnswers[currentQuestionIdx] === choiceQ?.answer
    : isCurrentAnswered && JSON.stringify(userAnswers[currentQuestionIdx]) === JSON.stringify(orderQ?.correctOrder);

  return (
    <div className="w-full max-w-5xl xl:max-w-6xl mx-auto px-3 sm:px-6 lg:px-8 space-y-6 text-white animate-in fade-in duration-300 pb-12">
      {!isSubmitted ? (
        <div className="bg-slate-900/90 backdrop-blur-2xl border border-cyan-500/30 p-5 sm:p-8 lg:p-10 rounded-3xl shadow-2xl space-y-6">
          
          {/* HEADER DEL TEST */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
            <div className="flex items-center gap-3">
              {onGoToCatalog && (
                <button
                  type="button"
                  onClick={onGoToCatalog}
                  title="Volver al Centro de Tests"
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-slate-300 hover:text-white transition-all cursor-pointer"
                >
                  <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="hidden sm:inline">Centro de Tests</span>
                </button>
              )}

              <div className="flex items-center gap-2.5">
                <span className="text-2xl p-1.5 rounded-xl bg-slate-950 border border-slate-800">{lesson.icon}</span>
                <div>
                  <h2 className="text-sm sm:text-base font-black text-white leading-tight">
                    Test de Verificación • Tema {lesson.id}/12
                  </h2>
                  <span className="text-xs text-cyan-400 font-mono font-bold block">
                    {lesson.title}
                  </span>
                </div>
              </div>
            </div>

            <span className="text-xs font-mono font-bold px-3.5 py-1.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shrink-0">
              Pregunta {currentQuestionIdx + 1} de {questions.length}
            </span>
          </div>

          {/* BARRA DE PROGRESO DEL TEST */}
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-indigo-500 to-cyan-400 h-full transition-all duration-300"
              style={{ width: `${((currentQuestionIdx + 1) / questions.length) * 100}%` }}
            />
          </div>

          {/* FOTOGRAFÍA ILUSTRATIVA DE LA PREGUNTA (SI EXISTE) */}
          {currentQ.photo && (
            <div className="relative w-full h-48 sm:h-64 rounded-2xl overflow-hidden border border-cyan-500/30 bg-slate-950 shadow-lg">
              <img
                src={currentQ.photo}
                referrerPolicy="no-referrer"
                alt={currentQ.question}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 left-2 px-2.5 py-1 rounded-lg bg-slate-950/80 backdrop-blur-md border border-cyan-400/40 text-[10px] font-bold text-cyan-300">
                Observación Científica
              </div>
            </div>
          )}

          {/* ENUNCIADO DE LA PREGUNTA */}
          <div className="space-y-2">
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
              {isChoice ? 'Selecciona la respuesta correcta:' : 'Ordena los elementos cronológicamente o por escala:'}
            </span>
            <h3 className="text-base sm:text-xl font-bold text-slate-100 leading-snug">
              {currentQ.question}
            </h3>
          </div>

          {/* OPCIONES MULTI-CHOICE */}
          {isChoice && (
            <div className="grid grid-cols-1 gap-3">
              {choiceQ.options.map((opt, optIdx) => {
                const isSelected = userAnswers[currentQuestionIdx] === optIdx;
                const isCorrectOption = choiceQ.answer === optIdx;
                
                let btnStyle = 'bg-slate-950/80 border-slate-800 hover:border-cyan-500/40 text-slate-200';
                if (isCurrentAnswered) {
                  if (isCorrectOption) {
                    btnStyle = 'bg-emerald-950/80 border-emerald-500 text-emerald-100 font-bold shadow-lg shadow-emerald-950/30';
                  } else if (isSelected) {
                    btnStyle = 'bg-rose-950/80 border-rose-500 text-rose-200 line-through';
                  } else {
                    btnStyle = 'bg-slate-950/30 border-slate-900 text-slate-600 opacity-40';
                  }
                }

                return (
                  <button
                    key={optIdx}
                    type="button"
                    disabled={isCurrentAnswered}
                    onClick={() => handleSelectChoice(optIdx)}
                    className={`w-full min-h-[52px] p-4 rounded-2xl border text-left text-xs sm:text-sm font-medium transition-all flex items-center justify-between gap-3 active:scale-[0.99] cursor-pointer ${btnStyle}`}
                  >
                    <span>{opt}</span>
                    {isCurrentAnswered && isCorrectOption && (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    )}
                    {isCurrentAnswered && isSelected && !isCorrectOption && (
                      <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          )}

          {/* PREGUNTA DE ORDENACIÓN */}
          {!isChoice && (
            <InteractiveOrderList
              items={orderQ.items}
              isSubmitted={isCurrentAnswered}
              correctOrder={orderQ.correctOrder}
              userOrder={userAnswers[currentQuestionIdx]}
              onOrderChange={handleOrderChange}
              onConfirmOrder={handleConfirmOrder}
            />
          )}

          {/* RETROALIMENTACIÓN FORMATIVA INMEDIATA */}
          {isCurrentAnswered && (
            <div
              className={`p-4 sm:p-5 rounded-2xl border text-xs sm:text-sm space-y-2 animate-in fade-in duration-300 ${
                isCurrentCorrect
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
                  : 'bg-amber-950/60 border-amber-500/40 text-amber-200'
              }`}
            >
              <div className="flex items-center gap-2 font-bold font-display">
                <Lightbulb className={`w-4 h-4 ${isCurrentCorrect ? 'text-emerald-400' : 'text-amber-400'}`} />
                <span>{isCurrentCorrect ? '¡Correcto! Fundamento Científico:' : 'Explicación del Concepto:'}</span>
              </div>
              <p className="text-slate-200 leading-relaxed">
                {currentQ.explanation || (isCurrentCorrect 
                  ? '¡Excelente deducción! Has aplicado con precisión los principios explicados en la lección.'
                  : 'Repasa este punto en la teoría: las leyes astronómicas y la escala cósmica determinan este comportamiento.')}
              </p>
            </div>
          )}

          {/* BOTÓN SIGUIENTE PREGUNTA */}
          {isCurrentAnswered && (
            <div className="pt-4 border-t border-white/10 flex justify-end">
              <button
                type="button"
                onClick={handleNextQuestion}
                className="min-h-[48px] py-3 px-6 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs sm:text-sm shadow-xl shadow-cyan-500/30 flex items-center gap-2 transition-all active:scale-[0.98] border border-cyan-400 cursor-pointer"
              >
                <span>{currentQuestionIdx < questions.length - 1 ? 'Siguiente Pregunta' : 'Ver Resultados del Examen'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      ) : (
        /* PANTALLA DE RESULTADOS GAMIFICADA */
        <div className="bg-slate-900/90 backdrop-blur-2xl border border-cyan-500/40 p-6 sm:p-10 rounded-3xl shadow-2xl text-center space-y-6 animate-in zoom-in-95 duration-300">
          <div className="inline-flex p-4 sm:p-5 rounded-3xl bg-cyan-950/60 border border-cyan-500/40 shadow-inner">
            <Award className="w-12 h-12 sm:w-16 sm:h-16 text-amber-400 animate-bounce" />
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl sm:text-3xl font-black text-white font-display">
              ¡Examen del Tema {lesson.id} Finalizado!
            </h2>
            <p className="text-sm sm:text-base text-cyan-300 font-mono">
              Has acertado {score} de {questions.length} preguntas ({Math.round((score / questions.length) * 100)}%)
            </p>
          </div>

          {/* ESTRELLAS CONSEGUIDAS */}
          <div className="flex items-center justify-center gap-3">
            {[1, 2, 3].map((starIdx) => {
              const starsCount = score === questions.length ? 3 : score >= Math.ceil(questions.length / 2) ? 2 : 1;
              return (
                <Star
                  key={starIdx}
                  className={`w-9 h-9 sm:w-12 sm:h-12 transition-all ${
                    starIdx <= starsCount
                      ? 'text-amber-400 fill-amber-400 animate-in zoom-in duration-300 drop-shadow-[0_0_12px_rgba(251,191,36,0.7)]'
                      : 'text-slate-700'
                  }`}
                />
              );
            })}
          </div>

          {/* BOTONERA DE ACCIONES DE SALIDA (48PX MIN TOUCH) */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-6 border-t border-white/10">
            <button
              type="button"
              onClick={handleRetry}
              className="min-h-[48px] py-3 px-4 rounded-2xl bg-slate-950 hover:bg-slate-800 text-slate-300 font-bold text-xs sm:text-sm border border-slate-800 flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Repetir Test</span>
            </button>

            {onGoToCatalog && (
              <button
                type="button"
                onClick={onGoToCatalog}
                className="min-h-[48px] py-3 px-4 rounded-2xl bg-slate-950 hover:bg-slate-800 text-slate-200 font-bold text-xs sm:text-sm border border-slate-700 flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
              >
                <span>📋 Catálogo Tests</span>
              </button>
            )}

            <button
              type="button"
              onClick={onGoTo3D}
              className="min-h-[48px] py-3 px-4 rounded-2xl bg-slate-950 hover:bg-slate-800 text-cyan-300 font-bold text-xs sm:text-sm border border-cyan-500/40 flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
            >
              <Rocket className="w-4 h-4 text-cyan-400" />
              <span>Ver en 3D</span>
            </button>

            <button
              type="button"
              onClick={onGoToNextLesson}
              className="min-h-[48px] py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs sm:text-sm shadow-xl shadow-emerald-500/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98] border border-emerald-400 cursor-pointer"
            >
              <span>Siguiente Tema</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

