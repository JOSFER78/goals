/**
 * GOALS 3D Cosmos - AstroExperience (Orquestador React Modular)
 * Gestiona de forma limpia las 3 pestañas principales de la experiencia:
 * 1. [📖 Lecciones]: Catálogo y lectura teórica paso a paso con fotos NASA.
 * 2. [🎯 Tests]: Evaluaciones formativas con XP y estrellas.
 * 3. [🌌 Explorar 3D]: Simulador 3D espacial WebGL2 con controles y telemetría.
 */

import React, { useState } from 'react';
import { LESSONS } from './data/lessonsData';
import { Lesson } from './types';
import { Cosmos3DCanvas } from './components/Cosmos3DCanvas';
import { LessonTheoryView } from './components/LessonTheoryView';
import { LessonTestView } from './components/LessonTestView';
import { useProgress } from '../../core/context/ProgressContext';
import { useAuth } from '../../core/context/AuthContext';
import { studentStateService } from '../../core/services/StudentStateService';
import { LegacyCurriculumAdapter } from '../../core/services/LegacyCurriculumAdapter';
import { BookOpen, CheckCircle2, Sparkles, ChevronRight } from 'lucide-react';

import { TestsCatalogHub } from './components/TestsCatalogHub';
import { CosmicLearningPath } from './components/CosmicLearningPath';

interface AstroExperienceProps {
  onBackToGoals: () => void;
  onOpenProfile: () => void;
  onOpenAuth?: (mode: 'login' | 'signup') => void;
}

export const AstroExperience: React.FC<AstroExperienceProps> = ({
  onBackToGoals,
  onOpenProfile,
  onOpenAuth
}) => {
  const { user } = useAuth();
  const { userData, finishTest, completeStep, isLessonUnlocked, isTestUnlocked, showToast } = useProgress();

  // Pestaña activa ('learn' | 'tests' | 'explore')
  const [activeTab, setActiveTab] = useState<'learn' | 'tests' | 'explore'>('explore');
  const [currentLessonId, setCurrentLessonId] = useState<number>(1);
  const [isReadingLesson, setIsReadingLesson] = useState<boolean>(false);
  const [isTakingTest, setIsTakingTest] = useState<boolean>(false);
  const [isBottomNavCollapsed, setIsBottomNavCollapsed] = useState<boolean>(false);

  const currentLesson: Lesson = LESSONS.find(l => l.id === currentLessonId) || LESSONS[0];

  const handleSelectLesson = (id: number) => {
    setCurrentLessonId(id);
    setIsReadingLesson(true);
  };

  const handleSelectTest = (id: number) => {
    setCurrentLessonId(id);
    setIsTakingTest(true);
  };

  return (
    <div className="relative w-full h-full min-h-[calc(100vh-60px)] flex flex-col bg-slate-950 overflow-hidden select-none">
      
      {/* ÁREA PRINCIPAL SEGÚN PESTAÑA ACTIVA */}
      <div className="flex-1 relative w-full h-full overflow-hidden flex flex-col">
        
        {/* PESTAÑA 1: LECCIONES TEÓRICAS */}
        {activeTab === 'learn' && (
          <div className="flex-1 w-full h-full overflow-y-auto p-3 sm:p-6 scrollbar-thin">
            {!isReadingLesson ? (
              /* RUTA DE APRENDIZAJE CÓSMICA (12 BLOQUES) */
              <CosmicLearningPath
                lessons={LESSONS}
                onSelectLesson={handleSelectLesson}
                onGoToTest={(id) => {
                  setCurrentLessonId(id);
                  setIsTakingTest(true);
                  setActiveTab('tests');
                }}
              />
            ) : (
              /* DETALLE DE LA LECCIÓN ACTIVA */
              <LessonTheoryView
                lesson={currentLesson}
                onGoToCatalog={() => setIsReadingLesson(false)}
                onSelectLesson={(id) => setCurrentLessonId(id)}
                onGoTo3D={(_target) => setActiveTab('explore')}
                onGoToTest={() => {
                  setIsTakingTest(true);
                  setActiveTab('tests');
                }}
                onStepComplete={(stepIdx) => completeStep(currentLesson.id, stepIdx)}
              />
            )}
          </div>
        )}

        {/* PESTAÑA 2: TESTS Y EVALUACIÓN */}
        {activeTab === 'tests' && (
          <div className="flex-1 w-full h-full overflow-y-auto p-3 sm:p-6 scrollbar-thin">
            {!isTakingTest ? (
              /* CENTRO DE EVALUACIONES Y TESTS INDEPENDIENTES */
              <TestsCatalogHub
                lessons={LESSONS}
                onSelectTest={handleSelectTest}
                onGoToLesson={(id) => {
                  setCurrentLessonId(id);
                  setIsReadingLesson(true);
                  setActiveTab('learn');
                }}
              />
            ) : (
              /* EXAMEN EN CURSO */
              <div className="space-y-4">
                {/* BARRA DE NAVEGACIÓN ENTRE TESTS */}
                <div className="max-w-3xl mx-auto flex items-center justify-between gap-2 p-2 bg-slate-900/90 backdrop-blur-md rounded-2xl border border-white/10 text-white">
                  <button
                    onClick={() => {
                      const prevId = Math.max(1, currentLesson.id - 1);
                      if (isTestUnlocked(prevId)) {
                        setCurrentLessonId(prevId);
                      } else {
                        showToast(`🔒 Completa la Lección ${prevId} para desbloquear este test`);
                      }
                    }}
                    disabled={currentLesson.id <= 1}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      currentLesson.id <= 1
                        ? 'opacity-40 text-slate-600 cursor-not-allowed'
                        : 'bg-slate-800 hover:bg-cyan-950 text-slate-200 hover:text-cyan-300 cursor-pointer'
                    }`}
                  >
                    ◀ Test {Math.max(1, currentLesson.id - 1)}
                  </button>

                  <button
                    onClick={() => setIsTakingTest(false)}
                    className="px-3 py-1 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-slate-300 hover:text-white transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <span>📋</span>
                    <span>Centro de Tests</span>
                  </button>

                  <button
                    onClick={() => {
                      const nextId = Math.min(12, currentLesson.id + 1);
                      if (isTestUnlocked(nextId)) {
                        setCurrentLessonId(nextId);
                      } else {
                        showToast(`🔒 Completa la Lección ${nextId} para desbloquear este test`);
                      }
                    }}
                    disabled={currentLesson.id >= 12}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      currentLesson.id >= 12
                        ? 'opacity-40 text-slate-600 cursor-not-allowed'
                        : 'bg-slate-800 hover:bg-cyan-950 text-slate-200 hover:text-cyan-300 cursor-pointer'
                    }`}
                  >
                    Test {Math.min(12, currentLesson.id + 1)} ▶
                  </button>
                </div>

                <LessonTestView
                  key={`test_${currentLesson.id}`}
                  lesson={currentLesson}
                  onGoToCatalog={() => setIsTakingTest(false)}
                  onFinishTest={(score, total) => {
                    const res = finishTest(currentLesson.id, score, total);
                    const nextCanonical = LegacyCurriculumAdapter.numericToCanonicalId(Math.min(LESSONS.length, currentLesson.id + 1));
                    studentStateService.completeUnit(
                      user?.uid || 'guest',
                      'astro',
                      LegacyCurriculumAdapter.numericToCanonicalId(currentLesson.id),
                      Math.round((score / total) * 100),
                      res.xpGained,
                      nextCanonical
                    );
                    return res;
                  }}
                  onGoToNextLesson={() => {
                    const nextId = Math.min(LESSONS.length, currentLesson.id + 1);
                    setCurrentLessonId(nextId);
                    setIsReadingLesson(true);
                    setActiveTab('learn');
                  }}
                  onGoTo3D={() => setActiveTab('explore')}
                />
              </div>
            )}
          </div>
        )}

        {/* PESTAÑA 3: SIMULADOR 3D FOTORREALISTA */}
        {activeTab === 'explore' && (
          <div className="flex-1 relative w-full h-full overflow-hidden">
            <Cosmos3DCanvas 
              onBackToGoals={onBackToGoals} 
              onOpenProfile={onOpenProfile} 
              showControls={true} 
            />
          </div>
        )}

      </div>

      {/* TIRADOR DE AUTOPLEGADO PARA MODO EXPLORAR 3D */}
      <div className="relative shrink-0 flex flex-col items-center">
        {activeTab === 'explore' && (
          <div className="absolute -top-7 z-50 flex justify-center w-full pointer-events-none">
            <button
              onClick={() => setIsBottomNavCollapsed(!isBottomNavCollapsed)}
              className="pointer-events-auto px-4 py-1 rounded-t-xl bg-slate-950/95 hover:bg-slate-900 border-t border-x border-cyan-500/40 text-[11px] font-mono font-extrabold text-cyan-300 backdrop-blur-2xl shadow-2xl flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 shadow-cyan-950"
              title={isBottomNavCollapsed ? 'Desplegar Barra de Navegación (Lecciones / Tests)' : 'Plegar Barra de Navegación para más espacio 3D'}
              aria-expanded={!isBottomNavCollapsed}
            >
              <span className="text-cyan-400 font-bold">{isBottomNavCollapsed ? '▲' : '▼'}</span>
              <span>{isBottomNavCollapsed ? 'Barra de Navegación' : 'Plegar Barra'}</span>
            </button>
          </div>
        )}

        {/* NAVEGACIÓN INFERIOR DE 3 PESTAÑAS */}
        {!isBottomNavCollapsed && (
          <nav className="w-full flex border-t border-slate-800 bg-slate-950/95 backdrop-blur-xl z-40 shrink-0">
            <button 
              onClick={() => setActiveTab('learn')}
              className={`flex-1 py-2 flex flex-col items-center gap-0.5 text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'learn' ? 'text-cyan-400 font-extrabold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Lecciones</span>
            </button>

            <button 
              onClick={() => setActiveTab('tests')}
              className={`flex-1 py-2 flex flex-col items-center gap-0.5 text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'tests' ? 'text-cyan-400 font-extrabold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Tests</span>
            </button>

            <button 
              onClick={() => setActiveTab('explore')}
              className={`flex-1 py-2 flex flex-col items-center gap-0.5 text-xs font-bold transition-all cursor-pointer relative ${
                activeTab === 'explore' ? 'text-cyan-400 font-extrabold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Explorar 3D</span>
            </button>
          </nav>
        )}
      </div>

    </div>
  );
};

export default AstroExperience;
