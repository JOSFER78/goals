/**
 * src/core/services/DiagnosticEngine.ts
 * Motor de Diagnóstico Inicial Adaptativo (6–15 años)
 * Calibra el punto de entrada pedagógico del estudiante mediante
 * un micro-test de 4 a 5 ítems de búsqueda binaria conceptual.
 */

import { 
  DiagnosticItem, 
  DiagnosticSession, 
  DiagnosticResult, 
  StudentLearningState
} from '../types/adaptiveCurriculum';
import { PresentationEngine } from './PresentationEngine';

const ASTRO_DIAGNOSTIC_BANK: DiagnosticItem[] = [
  // 6-7 años (Primaria 1º ciclo)
  {
    id: 'diag_astro_6_01',
    disciplineId: 'astro',
    conceptKey: 'dia_noche_rotacion',
    ageTranche: '6-7',
    difficulty: 'easy',
    prompt: '¿Por qué se hace de noche en la Tierra?',
    options: [
      'Porque la Tierra gira sobre sí misma como una peonza 🌍',
      'Porque el Sol se apaga y se va a dormir 😴',
      'Porque la Luna tapa al Sol con una manta 🌙'
    ],
    correctAnswer: 0,
    explanation: 'La Tierra está girando continuamente. Cuando nuestra parte queda de espaldas al Sol, es de noche.',
    targetUnitId: 'astro_u03_rotation_day_night'
  },
  {
    id: 'diag_astro_6_02',
    disciplineId: 'astro',
    conceptKey: 'sistema_solar_sol',
    ageTranche: '6-7',
    difficulty: 'easy',
    prompt: '¿Qué es el Sol que brilla en el cielo?',
    options: [
      'Una estrella gigante muy caliente y brillante ☀️',
      'Un planeta hecho de roca y arena 🪨',
      'Un satélite como la Luna 🛰️'
    ],
    correctAnswer: 0,
    explanation: 'El Sol es una estrella, el corazón brillante y caliente alrededor del cual giran todos los planetas.',
    targetUnitId: 'astro_u06_solar_system_planets'
  },

  // 8-9 años (Primaria 2º ciclo)
  {
    id: 'diag_astro_8_01',
    disciplineId: 'astro',
    conceptKey: 'eclipses_geometria',
    ageTranche: '8-9',
    difficulty: 'medium',
    prompt: '¿Qué ocurre durante un Eclipse Total de Sol como el del 12 de agosto de 2026 en España?',
    options: [
      'La Luna se coloca exactamente entre el Sol y la Tierra, proyectando su sombra',
      'La Tierra se aleja tanto del Sol que se congela el cielo',
      'El Sol pasa por detrás de la Luna y de Marte a la vez'
    ],
    correctAnswer: 0,
    explanation: 'La Luna pasa entre el Sol y la Tierra y bloquea el disco solar durante unos minutos.',
    targetUnitId: 'astro_u02_eclipses'
  },
  {
    id: 'diag_astro_8_02',
    disciplineId: 'astro',
    conceptKey: 'estaciones_inclinacion',
    ageTranche: '8-9',
    difficulty: 'medium',
    prompt: '¿Por qué hace más calor en verano en el hemisferio norte?',
    options: [
      'Porque el eje de la Tierra está inclinado hacia el Sol y los rayos caen más directos',
      'Porque la Tierra está mucho más cerca del Sol en julio',
      'Porque el Sol arde con mayor potencia en verano'
    ],
    correctAnswer: 0,
    explanation: 'La inclinación axial de 23,44° hace que los rayos solares incidan con mayor verticalidad en verano.',
    targetUnitId: 'astro_u05_seasons_obliquity'
  },

  // 10-11 años (Primaria 3º ciclo)
  {
    id: 'diag_astro_10_01',
    disciplineId: 'astro',
    conceptKey: 'gravedad_orbital_iss',
    ageTranche: '10-11',
    difficulty: 'medium',
    prompt: '¿Por qué flotan los astronautas en la Estación Espacial Internacional (ISS) a 418 km de altura?',
    options: [
      'Porque están en caída libre continua a 27.600 km/h alrededor de la curvatura terrestre',
      'Porque a esa altitud la gravedad de la Tierra es exactamente 0',
      'Porque la nave está llena de un gas antigravitatorio',
      'Porque la Luna los atrae con la misma fuerza que la Tierra'
    ],
    correctAnswer: 0,
    explanation: 'La gravedad a esa altura sigue siendo el 90% de la superficie; flotan por caída libre continua orbital.',
    targetUnitId: 'astro_u01_earth_atmosphere'
  },
  {
    id: 'diag_astro_10_02',
    disciplineId: 'astro',
    conceptKey: 'ano_luz_distancias',
    ageTranche: '10-11',
    difficulty: 'hard',
    prompt: '¿Qué mide un Año Luz en astronomía?',
    options: [
      'La distancia recorrida por la luz en un año (~9,46 billones de kilómetros)',
      'El tiempo que tarda la Tierra en dar una vuelta completa al Sol',
      'El brillo total emitido por una estrella gigante',
      'La velocidad de un cohete espacial'
    ],
    correctAnswer: 0,
    explanation: 'El año luz es una unidad de distancia física interestelar.',
    targetUnitId: 'astro_u08_nearby_stars_centauri'
  },

  // 12-13 años (ESO 1º ciclo)
  {
    id: 'diag_astro_12_01',
    disciplineId: 'astro',
    conceptKey: 'materia_oscura_curva_rotacion',
    ageTranche: '12-13',
    difficulty: 'hard',
    prompt: '¿Qué evidencia observacional demostró la existencia de un halo de Materia Oscura en la Vía Láctea?',
    options: [
      'Las curvas de rotación planas donde las estrellas exteriores giran a la misma velocidad (~220 km/s) que las interiores',
      'Que el centro de la galaxia no emite ninguna radiación de radio',
      'Que las galaxias elípticas tienen formas esféricas perfectas',
      'Que los eclipses solares duran exactamente 2 minutos'
    ],
    correctAnswer: 0,
    explanation: 'La curva de rotación galáctica plana requirió la presencia de un 85% de masa no visible (materia oscura).',
    targetUnitId: 'astro_u09_milky_way_black_hole'
  },

  // 14-15 años (ESO 2º ciclo)
  {
    id: 'diag_astro_14_01',
    disciplineId: 'astro',
    conceptKey: 'cmb_big_bang_energia_oscura',
    ageTranche: '14-15',
    difficulty: 'hard',
    prompt: '¿Por qué el diámetro del Universo Observable mide 93.000 millones de años luz si el cosmos tiene 13.800 millones de años de edad?',
    options: [
      'Porque el propio tejido del espacio-tiempo se ha expandido continuamente mientras la luz viajaba',
      'Porque los fotones aumentan su velocidad por encima de c en el vacío',
      'Porque la constante de Planck varía con el tiempo cósmico',
      'Porque la gravedad atrae a los fotones hacia el centro'
    ],
    correctAnswer: 0,
    explanation: 'La expansión comóvil del espacio sitúa el horizonte de partículas actual en un radio de 46.500 millones de al.',
    targetUnitId: 'astro_u12_observable_universe_cmb'
  }
];

export class DiagnosticEngine {
  /**
   * Obtiene los ítems diagnósticos para un estudiante según disciplina y edad
   */
  public static getDiagnosticItemsForStudent(disciplineId: string, age: number): DiagnosticItem[] {
    const tranche = PresentationEngine.getTrancheForAge(age);
    const bank = ASTRO_DIAGNOSTIC_BANK.filter(item => item.disciplineId === disciplineId);

    const exactTrancheItems = bank.filter(i => i.ageTranche === tranche);
    const otherItems = bank.filter(i => i.ageTranche !== tranche);

    const selected = [...exactTrancheItems, ...otherItems].slice(0, 4);
    return selected.length >= 3 ? selected : bank.slice(0, 4);
  }

  public static getItems(disciplineId: string, age: number): DiagnosticItem[] {
    return this.getDiagnosticItemsForStudent(disciplineId, age);
  }

  /**
   * Evalúa el resultado del diagnóstico
   */
  public static evaluateDiagnostic(
    userId: string,
    disciplineId: string,
    declaredAge: number,
    answers: Array<{ itemId: string; selectedOption: number; isCorrect: boolean; conceptKey: string }>
  ): DiagnosticResult {
    let correctCount = 0;
    const strengths: string[] = [];
    const weakConcepts: string[] = [];
    let fallbackUnitId = 'astro_u01_earth_atmosphere';

    answers.forEach(ans => {
      if (ans.isCorrect) {
        correctCount++;
        strengths.push(ans.conceptKey);
      } else {
        weakConcepts.push(ans.conceptKey);
        const item = ASTRO_DIAGNOSTIC_BANK.find(i => i.id === ans.itemId);
        if (item) {
          fallbackUnitId = item.targetUnitId;
        }
      }
    });

    const percent = Math.round((correctCount / Math.max(1, answers.length)) * 100);
    
    let startUnitId = 'astro_u01_earth_atmosphere';
    if (percent === 100) {
      startUnitId = declaredAge >= 12 ? 'astro_u07_oort_cloud_voyager' : declaredAge >= 9 ? 'astro_u04_orbit_kepler' : 'astro_u02_eclipses';
    } else if (percent >= 50) {
      startUnitId = declaredAge >= 10 ? 'astro_u03_rotation_day_night' : 'astro_u01_earth_atmosphere';
    } else {
      startUnitId = fallbackUnitId || 'astro_u01_earth_atmosphere';
    }

    return {
      userId,
      disciplineId,
      estimatedAgeLevel: declaredAge,
      recommendedStartUnitId: startUnitId,
      detectedStrengths: strengths,
      detectedWeakConcepts: weakConcepts,
      initialMasteryPercent: percent
    };
  }

  /**
   * Crea el StudentLearningState a partir de la evaluación
   */
  public static createStudentStateFromResult(
    userId: string,
    disciplineId: string,
    declaredAge: number,
    declaredGrade: string,
    result: DiagnosticResult
  ): StudentLearningState {
    const conceptMastery: StudentLearningState['conceptMastery'] = {};

    result.detectedStrengths.forEach(cKey => {
      conceptMastery[cKey] = {
        conceptKey: cKey,
        scorePercent: 100,
        totalAttempts: 1,
        lastPracticedAt: Date.now(),
        status: 'mastered'
      };
    });

    result.detectedWeakConcepts.forEach(cKey => {
      conceptMastery[cKey] = {
        conceptKey: cKey,
        scorePercent: 30,
        totalAttempts: 1,
        lastPracticedAt: Date.now(),
        status: 'needs_reinforcement'
      };
    });

    return {
      userId,
      disciplineId,
      age: declaredAge,
      grade: declaredGrade,
      diagnosticStatus: 'completed',
      diagnosticScore: result.initialMasteryPercent,
      diagnosticDate: Date.now(),
      recommendedStartUnitId: result.recommendedStartUnitId,
      currentUnitId: result.recommendedStartUnitId,
      completedUnitIds: [],
      conceptMastery,
      weakConcepts: result.detectedWeakConcepts,
      strengths: result.detectedStrengths,
      sessionHistory: [],
      lastActiveAt: Date.now(),
      updatedAt: Date.now()
    };
  }

  public static createSession(userId: string, disciplineId: string, age: number, grade: string): DiagnosticSession {
    const items = this.getDiagnosticItemsForStudent(disciplineId, age);
    return {
      sessionId: `diag_${userId}_${Date.now()}`,
      userId,
      disciplineId,
      declaredAge: age,
      declaredGrade: grade,
      currentStep: 0,
      totalSteps: items.length,
      items,
      answers: [],
      isCompleted: false
    };
  }
}
