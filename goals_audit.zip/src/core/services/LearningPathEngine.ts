/**
 * src/core/services/LearningPathEngine.ts
 * Motor de Generación del Camino del Alumno ("Mi Camino")
 * Calcula de forma determinista la ruta personalizada, identificando
 * la unidad activa, próximas metas y cápsulas de refuerzo adaptativo.
 */

import { 
  LearningPath, 
  LearningPathItem, 
  StudentLearningState, 
  CurriculumUnit 
} from '../types/adaptiveCurriculum';
import { LegacyCurriculumAdapter } from './LegacyCurriculumAdapter';

export class LearningPathEngine {
  /**
   * Genera la estructura completa de "Mi Camino" para el alumno (alias para computeLearningPath)
   */
  public static computeLearningPath(
    state: StudentLearningState,
    customUnits?: CurriculumUnit[]
  ): LearningPath {
    return this.calculateLearningPath(state, customUnits);
  }

  public static calculateLearningPath(
    state: StudentLearningState,
    customUnits?: CurriculumUnit[]
  ): LearningPath {
    const units: CurriculumUnit[] = customUnits || LegacyCurriculumAdapter.getAllUnits();
    const completedIds = new Set(state.completedUnitIds || []);

    const pathItems: LearningPathItem[] = units.map((unit: CurriculumUnit) => {
      const isCompleted = completedIds.has(unit.id);
      const prereqsMet = (unit.prerequisites || []).every((pId: string) => completedIds.has(pId));
      
      let status: LearningPathItem['status'] = 'locked';
      if (isCompleted) {
        status = 'completed';
      } else if (unit.id === state.currentUnitId) {
        status = 'current';
      } else if (prereqsMet) {
        status = 'upcoming';
      }

      const mastery = state.conceptMastery?.[unit.id]?.scorePercent;

      return {
        unitId: unit.id,
        canonicalNumber: unit.canonicalNumber,
        title: unit.title,
        subtitle: unit.subtitle,
        icon: unit.icon,
        xpReward: unit.xpReward,
        ageTranche: unit.ageTranche,
        status,
        masteryPercent: mastery,
        prerequisitesMet: prereqsMet
      };
    });

    const completedUnits = pathItems.filter(i => i.status === 'completed');
    
    // Determinar la unidad actual
    let currentUnit = pathItems.find(i => i.unitId === state.currentUnitId);
    if (!currentUnit) {
      currentUnit = pathItems.find(i => i.status === 'upcoming') || pathItems[0];
    }

    // Próximas 2 o 3 unidades
    const upcomingUnits = pathItems
      .filter(i => i.unitId !== currentUnit?.unitId && (i.status === 'upcoming' || i.status === 'locked'))
      .slice(0, 3);

    // Unidad de refuerzo si hay lagunas
    let reinforcementUnit: LearningPathItem | undefined;
    if (state.weakConcepts && state.weakConcepts.length > 0) {
      const weakConcept = state.weakConcepts[0];
      const matchingUnit = pathItems.find(u => u.unitId.includes(weakConcept) || completedIds.has(u.unitId));
      if (matchingUnit) {
        reinforcementUnit = {
          ...matchingUnit,
          status: 'reinforcement',
          title: `Refuerzo: ${matchingUnit.title}`,
          subtitle: 'Consolida los conceptos con una práctica rápida'
        };
      }
    }

    const progressPercent = Math.round((completedUnits.length / Math.max(1, units.length)) * 100);

    return {
      userId: state.userId,
      disciplineId: state.disciplineId,
      totalUnitsInCurriculum: units.length,
      completedUnitsCount: completedUnits.length,
      progressPercent,
      currentUnit: currentUnit || pathItems[0],
      upcomingUnits,
      completedUnits,
      reinforcementUnit,
      activeStreak: 1,
      totalStars: completedUnits.length * 3
    };
  }
}
