import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useProgress } from '../../context/ProgressContext';
import { PresentationEngine } from '../../services/PresentationEngine';
import { DiagnosticEngine } from '../../services/DiagnosticEngine';
import { studentStateService } from '../../services/StudentStateService';
import { 
  Sparkles, GraduationCap, User, ArrowRight, CheckCircle2, 
  HelpCircle, Compass, Rocket, Brain, Star, Bot
} from 'lucide-react';
import { DiagnosticItem, DiagnosticResult } from '../../types/adaptiveCurriculum';

interface InitialOnboardingGateProps {
  onComplete: () => void;
}

export const InitialOnboardingGate: React.FC<InitialOnboardingGateProps> = ({ onComplete }) => {
  const { user } = useAuth();
  const { saveChildProfileData, showToast } = useProgress();

  const [step, setStep] = useState<'profile' | 'diagnostic' | 'result'>('profile');
  const [name, setName] = useState<string>(user?.displayName || '');
  const [selectedAge, setSelectedAge] = useState<number>(9);
  const [selectedAvatar, setSelectedAvatar] = useState<string>('astrobot');

  // Estado del Diagnóstico
  const [diagnosticItems, setDiagnosticItems] = useState<DiagnosticItem[]>([]);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState<number>(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [diagnosticResult, setDiagnosticResult] = useState<DiagnosticResult | null>(null);
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);

  const levelBadge = PresentationEngine.getLevelBadge(selectedAge);
  const presentationProfile = PresentationEngine.computeProfile(selectedAge);

  const handleStartDiagnostic = () => {
    if (!name.trim()) {
      showToast('Por favor, escribe tu nombre o apodo.');
      return;
    }
    const items = DiagnosticEngine.getDiagnosticItemsForStudent('astro', selectedAge);
    setDiagnosticItems(items);
    setCurrentQuestionIdx(0);
    setAnswers({});
    setStep('diagnostic');
  };

  const handleSelectAnswer = (optionIdx: number) => {
    const currentItem = diagnosticItems[currentQuestionIdx];
    const newAnswers = { ...answers, [currentItem.id]: optionIdx };
    setAnswers(newAnswers);

    if (currentQuestionIdx + 1 < diagnosticItems.length) {
      setCurrentQuestionIdx(prev => prev + 1);
    } else {
      // Finalizar y evaluar
      setIsEvaluating(true);
      setTimeout(async () => {
        const structuredAnswers = Object.entries(newAnswers).map(([itemId, selectedOption]) => {
          const item = diagnosticItems.find(i => i.id === itemId);
          const isCorrect = item ? item.correctAnswer === selectedOption : false;
          return {
            itemId,
            selectedOption,
            isCorrect,
            conceptKey: item?.conceptKey || 'general'
          };
        });

        const result = DiagnosticEngine.evaluateDiagnostic(
          user?.uid || 'guest_user',
          'astro',
          selectedAge,
          structuredAnswers
        );
        setDiagnosticResult(result);

        const studentState = DiagnosticEngine.createStudentStateFromResult(
          user?.uid || 'guest_user',
          'astro',
          selectedAge,
          levelBadge.label.split(' (')[0],
          result
        );

        // Guardar en Firestore y estado global
        if (user?.uid) {
          await studentStateService.saveStudentState(studentState);
        }

        saveChildProfileData({
          childName: name.trim(),
          age: selectedAge,
          grade: levelBadge.label.split(' (')[0],
          schoolName: '',
          favoriteSubjects: ['Ciencias Naturales', 'Astrofísica 🌌'],
          weakSubjects: [],
          extracurriculars: ['Robótica y Código 🤖'],
          interests: ['Espacio y Astronomía 🚀', 'Simulación 3D 🪐'],
          learningStyle: selectedAge <= 9 ? 'visual' : 'practico',
          avatar: selectedAvatar
        });

        setIsEvaluating(false);
        setStep('result');
      }, 700);
    }
  };

  const handleFinishAndEnter = () => {
    showToast(`🚀 ¡Calibración completada! Bienvenido a GOALS, ${name.trim()}.`);
    onComplete();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-2xl overflow-y-auto">
      <div className="w-full max-w-xl bg-slate-900/95 border border-indigo-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden my-auto">
        
        {/* Glow de fondo */}
        <div className="absolute -top-24 -right-24 w-64 h-64 rounded-full bg-indigo-600/20 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-64 h-64 rounded-full bg-cyan-600/20 blur-3xl pointer-events-none" />

        {/* PASO 1: SELECCIÓN DE EDAD Y PERFIL */}
        {step === 'profile' && (
          <div className="space-y-5 animate-fadeIn">
            <div className="text-center space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-mono font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Paso 1 de 2 · Calibración Inicial Obligatoria</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-white font-display">
                ¡Bienvenido a GOALS! 🚀
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
                Para adaptar las lecciones, los modelos 3D y el tutor IA a tu etapa escolar, indica tu edad y nombre:
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Nombre del Estudiante</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Tu nombre o apodo..."
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:border-indigo-500 outline-none transition-all font-medium"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <GraduationCap className="w-3.5 h-3.5 text-indigo-400" />
                    <span>¿Cuántos años tienes?</span>
                  </label>
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${levelBadge.color}`}>
                    {levelBadge.label}
                  </span>
                </div>

                <div className="grid grid-cols-5 gap-2">
                  {[
                    { age: 7, label: '6-7', stage: '1º-2º Pri', desc: 'Lúdico & Guiado' },
                    { age: 9, label: '8-9', stage: '3º-4º Pri', desc: 'Explorador' },
                    { age: 11, label: '10-11', stage: '5º-6º Pri', desc: 'Avanzado' },
                    { age: 13, label: '12-13', stage: '1º-2º ESO', desc: 'Científico Jr.' },
                    { age: 15, label: '14-15', stage: '3º-4º ESO', desc: 'Astrofísico / Formal' }
                  ].map(item => {
                    const isSelected = (selectedAge <= 7 && item.age === 7) ||
                                       (selectedAge >= 8 && selectedAge <= 9 && item.age === 9) ||
                                       (selectedAge >= 10 && selectedAge <= 11 && item.age === 11) ||
                                       (selectedAge >= 12 && selectedAge <= 13 && item.age === 13) ||
                                       (selectedAge >= 14 && item.age === 15);
                    return (
                      <button
                        key={item.age}
                        type="button"
                        onClick={() => setSelectedAge(item.age)}
                        className={`p-2.5 rounded-2xl border text-center transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-indigo-600/30 border-indigo-400 text-white shadow-[0_0_20px_rgba(99,102,241,0.3)] scale-[1.03]'
                            : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                        }`}
                      >
                        <div className="text-sm font-extrabold font-mono">{item.label}</div>
                        <div className="text-[10px] text-indigo-300 font-semibold">{item.stage}</div>
                        <div className="text-[8px] text-slate-500 truncate mt-0.5">{item.desc}</div>
                      </button>
                    );
                  })}
                </div>

                <div className="mt-3 p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-start gap-2.5 text-xs text-slate-300">
                  <Brain className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-white">Enfoque pedagógico activo: </span>
                    <span className="text-slate-400">
                      {presentationProfile.interactionMode === 'playful_guided' && 'Explicaciones lúdicas con analogías visuales, animaciones y preguntas guiadas.'}
                      {presentationProfile.interactionMode === 'tactile_interactive' && 'Retos causales, modelos tridimensionales interactivos y fotografías de la NASA.'}
                      {presentationProfile.interactionMode === 'analytical_formal' && 'Fórmulas matemáticas (LaTeX), telemetría en vivo y rigor astrofísico oficial.'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleStartDiagnostic}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-extrabold text-sm transition-all shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
            >
              <span>Comenzar Micro-Diagnóstico Adaptativo</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* PASO 2: DIAGNÓSTICO EN VIVO */}
        {step === 'diagnostic' && diagnosticItems.length > 0 && (
          <div className="space-y-5 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-slate-300">
                  Pregunta {currentQuestionIdx + 1} de {diagnosticItems.length}
                </span>
              </div>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${levelBadge.color}`}>
                Nivel {levelBadge.label}
              </span>
            </div>

            {/* Barra de progreso */}
            <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800">
              <div 
                className="bg-gradient-to-r from-cyan-400 to-indigo-500 h-full transition-all duration-300 rounded-full"
                style={{ width: `${((currentQuestionIdx) / diagnosticItems.length) * 100}%` }}
              />
            </div>

            {/* Pregunta */}
            <div className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-white leading-snug">
                {diagnosticItems[currentQuestionIdx].prompt}
              </h3>
              <p className="text-[11px] text-slate-400">
                Selecciona la opción que mejor responda a la pregunta:
              </p>
            </div>

            {/* Opciones */}
            <div className="space-y-2.5">
              {diagnosticItems[currentQuestionIdx].options.map((option, idx) => (
                <button
                  key={idx}
                  type="button"
                  disabled={isEvaluating}
                  onClick={() => handleSelectAnswer(idx)}
                  className="w-full text-left p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800/90 hover:border-cyan-500/50 hover:bg-slate-900 text-xs sm:text-sm text-slate-200 hover:text-white transition-all cursor-pointer flex items-center justify-between group active:scale-[0.99]"
                >
                  <span className="leading-relaxed">{option}</span>
                  <div className="w-5 h-5 rounded-full border border-slate-700 flex items-center justify-center shrink-0 group-hover:border-cyan-400 group-hover:bg-cyan-500/20 text-cyan-300 text-xs transition-all">
                    {String.fromCharCode(65 + idx)}
                  </div>
                </button>
              ))}
            </div>

            {isEvaluating && (
              <div className="p-3 text-center text-xs font-mono text-cyan-300 animate-pulse">
                Calculando tu ruta personalizada y punto de entrada...
              </div>
            )}
          </div>
        )}

        {/* PASO 3: RESULTADO Y ACCESO DESBLOQUEADO */}
        {step === 'result' && diagnosticResult && (
          <div className="space-y-5 text-center animate-fadeIn">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-indigo-500/20 to-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mx-auto shadow-[0_0_30px_rgba(16,185,129,0.25)]">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h2 className="text-xl sm:text-2xl font-extrabold text-white font-display">
                ¡Calibración Completada! 🌟
              </h2>
              <p className="text-xs sm:text-sm text-slate-300">
                Puntuación Inicial: <span className="font-bold text-amber-300">{diagnosticResult.initialMasteryPercent}%</span> · Punto de entrada recomendado:
              </p>
            </div>

            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 text-left space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  Unidad Inicial Asignada
                </span>
                <span className="px-2 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-[10px] font-mono font-bold">
                  {levelBadge.label.split(' (')[0]}
                </span>
              </div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Rocket className="w-4 h-4 text-indigo-400" />
                <span>{diagnosticResult.recommendedStartUnitId.replace(/_/g, ' ').toUpperCase()}</span>
              </h4>
              <p className="text-xs text-slate-400">
                Tu ruta "Mi Camino" ha sido calibrada de forma personalizada para tu nivel escolar.
              </p>
            </div>

            <button
              type="button"
              onClick={handleFinishAndEnter}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 text-white font-extrabold text-sm transition-all shadow-lg shadow-emerald-600/25 flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
            >
              <span>Entrar al Dashboard de GOALS</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
