/**
 * GOALS 3D Cosmos Engine - PlanetSurfaceShader
 * Shader PBR Fotorrealista para Superficies Planetarias (Tierra, Luna, Marte)
 * Gestiona albedo diurno, luces nocturnas VIIRS, especular oceánico y relieve.
 */

import * as THREE from 'three';

export interface PlanetSurfaceUniforms {
  uDayTex: { value: THREE.Texture | null };
  uNightTex: { value: THREE.Texture | null };
  uSpecularMap: { value: THREE.Texture | null };
  uNormalMap: { value: THREE.Texture | null };
  uSunDir: { value: THREE.Vector3 };
  uShininess: { value: number };
  uDayIntensity: { value: number };
  uNightIntensity: { value: number };
}

export function createEarthPBRMaterial(
  dayTex: THREE.Texture,
  nightTex: THREE.Texture,
  specularTex: THREE.Texture,
  sunDir: THREE.Vector3,
  normalTex?: THREE.Texture | null
): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({
    uniforms: {
      uDayTex: { value: dayTex },
      uNightTex: { value: nightTex },
      uSpecularMap: { value: specularTex },
      uNormalMap: { value: normalTex || null },
      uSunDir: { value: sunDir },
      uShininess: { value: 64.0 },
      uDayIntensity: { value: 1.1 },
      uNightIntensity: { value: 2.8 }
    },
    vertexShader: `
      varying vec3 vWorldNormal;
      varying vec2 vUv;
      varying vec3 vViewPosition;
      varying vec3 vWorldPosition;

      void main() {
        vUv = uv;
        vWorldNormal = normalize(mat3(modelMatrix) * normal);
        vec4 worldPos = modelMatrix * vec4(position, 1.0);
        vWorldPosition = worldPos.xyz;
        vec4 mvPos = modelViewMatrix * vec4(position, 1.0);
        vViewPosition = -mvPos.xyz;
        gl_Position = projectionMatrix * mvPos;
      }
    `,
    fragmentShader: `
      uniform sampler2D uDayTex;
      uniform sampler2D uNightTex;
      uniform sampler2D uSpecularMap;
      uniform sampler2D uNormalMap;
      uniform vec3 uSunDir;
      uniform float uShininess;
      uniform float uDayIntensity;
      uniform float uNightIntensity;

      varying vec3 vWorldNormal;
      varying vec2 vUv;
      varying vec3 vViewPosition;
      varying vec3 vWorldPosition;

      void main() {
        vec3 norm = normalize(vWorldNormal);
        vec3 lightDir = normalize(uSunDir);
        vec3 viewDir = normalize(vViewPosition);

        // Producto escalar entre la normal y la luz solar
        float dotNL = dot(norm, lightDir);

        // Transición día / noche con terminador suave
        float dayFactor = smoothstep(-0.16, 0.26, dotNL);
        float nightFactor = smoothstep(0.18, -0.16, dotNL);

        // Muestreo de texturas satelitales NASA
        vec4 dayColor = texture2D(uDayTex, vUv) * uDayIntensity;
        vec4 nightColor = texture2D(uNightTex, vUv);
        float specMask = texture2D(uSpecularMap, vUv).r;

        // 1. Emisión de luces urbanas nocturnas (NASA Black Marble)
        vec3 nightLights = nightColor.rgb * nightFactor * uNightIntensity;

        // 2. Banda de atardecer / amanecer Rayleigh (Ámbar cálido)
        float twilight = smoothstep(-0.22, 0.04, dotNL) * smoothstep(0.26, -0.04, dotNL);
        vec3 twilightGlow = vec3(1.0, 0.46, 0.14) * twilight * 1.25;

        // 3. Destello especular del Sol sobre los océanos (Agua líquida)
        vec3 halfDir = normalize(lightDir + viewDir);
        float specComp = pow(max(dot(norm, halfDir), 0.0), uShininess);
        vec3 sunGlint = vec3(1.0, 0.96, 0.88) * specComp * specMask * dayFactor * 0.85;

        // 4. Fresnel atmosférico en el horizonte iluminado
        float fresnel = pow(1.0 - max(dot(norm, viewDir), 0.0), 2.8);
        vec3 atmoRim = vec3(0.22, 0.68, 1.0) * fresnel * max(dotNL + 0.3, 0.0) * 0.8;

        // 5. Luz diurna ambiental suave para evitar sombras 100% negras
        vec3 dayAmbient = dayColor.rgb * 0.07;

        // Composición final PBR
        vec3 finalColor = (dayColor.rgb * dayFactor) + dayAmbient + nightLights + twilightGlow + sunGlint + atmoRim;
        gl_FragColor = vec4(finalColor, 1.0);
      }
    `
  });
}
